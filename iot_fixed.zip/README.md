# Климат/IoT датчиктерінің дашборды

Бұл жоба температура және ылғалдылық көрсеткіштерін функционалды стильде өңдейтін
Streamlit дашборды. Код Лаб 1-2 және 1-4 дәріс тақырыптарын көрсетуге арналған:
таза функция, өзгермейтіндік, map/filter/reduce, lambda, рекурсия, замыкание,
partial, curry, compose/pipe және decorator.

## Іске қосу, PowerShell

```powershell
py -3.14 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe -m scripts.generate_seed
.\.venv\Scripts\python.exe -m streamlit run app/main.py
```

Тексеру командалары:

```powershell
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m black .
.\.venv\Scripts\python.exe -m ruff check . --fix
.\.venv\Scripts\python.exe -m black --check .
```

## UI навигациясы

| Мәзір | Мақсаты |
|---|---|
| Overview | Локация, құрылғы, сенсор, көрсеткіш саны және temp/hum статистикасы |
| Data | `Load seed` батырмасы және JSON бөлімдерін expander ішінде көру |
| Functional Core | `add_reading`, `apply_calibration`, `calibrated_readings`, `sort_readings`, `top_n_readings`, `timed` |
| Pipelines | Иерархиялық сүзу, `all_of`, `pipe + partial`, `avg_by_sensor`, `nest_readings_by_day` |
| Async/FRP | Лаб 6, 8 — әзірге placeholder |
| Reports | Лаб 3, 4, 7, 8 — әзірге placeholder |
| Tests | PowerShell тексеру командалары |
| About | Дәріс пен кодтағы орны кестесі |

## Функция сигнатуралары

- `load_seed(path) -> (locations, devices, sensors, readings, rules, alerts)`
- `add_reading(readings, reading) -> tuple[Reading, ...]`
- `apply_calibration(sensors, sensor_id, delta) -> tuple[Sensor, ...]`
- `calibrated_readings(readings, sensors) -> tuple[Reading, ...]`
- `readings_stats(readings, sensors, kind) -> dict`
- `by_sensor_kind(kind, sensors) -> Callable[[Reading], bool]`
- `by_location(location_id, locations, devices, sensors) -> Callable[[Reading], bool]`
- `by_time_range(start, end) -> Callable[[Reading], bool]`
- `all_of(*predicates) -> Callable[[Reading], bool]`
- `select(readings, predicate) -> tuple[Reading, ...]`
- `filter_data(data, condition) -> tuple`
- `transform_data(data, transformer) -> tuple`
- `aggregate_data(data, aggregator) -> object | None`
- `in_range(low, high) -> Callable[[Reading], bool]`
- `readings_in_range(readings, low, high) -> tuple[Reading, ...]`
- `sort_readings(readings, by, reverse=False) -> tuple[Reading, ...]`
- `top_n_readings(readings, n) -> tuple[Reading, ...]`
- `avg_by_sensor(readings) -> tuple[(sensor_id, avg), ...]`
- `collect_descendant_locations(locations, root_id) -> tuple[str, ...]`
- `find_sensors_in_location(locations, devices, sensors, root_id) -> tuple[Sensor, ...]`
- `nest_readings_by_day(readings) -> tuple[(day, tuple[Reading, ...]), ...]`
- `compose(*functions) -> Callable`
- `pipe(value, *functions) -> object`
- `curry2(function) -> Callable`
- `timed(function) -> Callable`
- `logged(sink) -> decorator`
- `type_checked(correct_type) -> decorator`

> Ескерту: тапсырмадағы `readings_stats(readings, kind)` сигнатурасына қосымша
> `sensors` аргументі қосылған, себебі `Reading` ішінде `kind` жоқ (ол `Sensor`-да).

## 1-4 дәріс -> файл/функция

| Дәріс | Кодтағы орны |
|---|---|
| 1-дәріс: FP парадигмасы | `app/core/transforms.py`, таза функциялар және immutable tuple |
| 2-дәріс: lambda, map/filter/reduce, рекурсия | `transforms.py`, `recursion.py` |
| 3-дәріс: таза функциялар және өзгермейтіндік | `domain.py`, `apply_calibration`, `calibrated_readings` |
| 4-дәріс: HOF, closure, partial, curry, decorator | `compose.py`, `by_*`, `main.py` |

## Қатысушылар үлесі

| Студент | Үлесі |
|---|---|
| <Аты-жөні 1> | domain.py, transforms.py, тесттер |
| <Аты-жөні 2> | recursion.py, compose.py, UI (main.py), README |
