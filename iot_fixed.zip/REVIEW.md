# Код ревью және QA есебі

Жоба: «Климат/IoT датчиктерінің дашборды»  
Тексеру күні: 2026-09-30  
Орта: Windows, `.venv`, Python 3.14

## Қорытынды

Жалпы баға: **7/10**.

Функционалдық жағынан жоба Лаб №1-2 және 1-4 дәріс тақырыптарын жақсы көрсетеді: immutable dataclass, tuple, `map/filter/reduce`, рекурсия, closure, `partial`, curry, decorator, compose/pipe бар. Негізгі тесттер толық өтеді: **27 passed**. Бірақ сапа gate бойынша жоба дайын емес: `ruff check .` және `black --check .` құлайды, root `.gitignore` жоқ, README-де қатысушылар үлесі `TODO`, ал malformed дерекке қорғаныс әлсіз.

## Автоматты тексеру нәтижелері

| Команда | Нәтиже |
|---|---|
| `.\.venv\Scripts\python.exe -m pytest -q` | ✅ Өтті: `27 passed in 0.09s` |
| `.\.venv\Scripts\python.exe -m ruff check .` | ❌ Құлады: **16 error**. Негізгісі: `E501` ұзын жолдар және `E731` тесттегі lambda assignment |
| `.\.venv\Scripts\python.exe -m black --check .` | ❌ Құлады: 6 файл reformatted болар еді: `tests/__init__.py`, `app/core/recursion.py`, `app/core/compose.py`, `tests/test_lab2.py`, `app/main.py`, `app/core/transforms.py` |
| `.\.venv\Scripts\python.exe -m py_compile ...` | ✅ Өтті: барлық жобалық `.py` файл синтаксис қатесіз компиляцияланды |
| `.\.venv\Scripts\python.exe -m streamlit run app/main.py --server.headless true --server.port 8765` | ✅ Smoke test өтті: сервер іске қосылды, `Traceback` табылмады, 7 секундтан кейін тоқтатылды |
| `.\.venv\Scripts\python.exe -m scripts.generate_seed` | ✅ Exit code `0`, seed детерминді: SHA256 before/after бірдей `7392A6C0FB1646D633442D9EC689D65E57C76902E7AF3B779A13B890D3CE8526` |

Ескерту: `git` бұл ортада PATH ішінде табылмады, сондықтан seed diff орнына SHA256 хэшпен салыстырылды.

## Талаптар матрицасы

| Талап | Күй | Файл:жол | Түсініктеме |
|---|---:|---|---|
| Seed: 2-3 жоғарғы локация | ✅ | `data/seed.json` | Нақты саны: **3** (`c1`, `c2`, `c3`) |
| Seed: ≥12 бөлме | ✅ | `data/seed.json` | Нақты саны: **15** room id (`-r`) |
| Seed: ≥8 құрылғы | ✅ | `data/seed.json` | Нақты саны: **12** |
| Seed: ≥20 сенсор | ✅ | `data/seed.json` | Нақты саны: **24** |
| Seed: ≥1000 көрсеткіш | ✅ | `data/seed.json` | Нақты саны: **1440** |
| Seed: ≥5 ереже | ✅ | `data/seed.json` | Нақты саны: **5** |
| Барлық domain модель frozen | ✅ | `app/core/domain.py:13`, `26`, `40`, `55`, `69`, `82` | Барлығы `@dataclass(frozen=True)` |
| Domain өрістері дұрыс типтелген | ✅ | `app/core/domain.py:21`, `34`, `48`, `63`, `77`, `90` | `Sensor.kind/unit` және `Rule.kind` үшін `Literal` бар |
| `Rule.payload` толық immutable | ⚠️ | `app/core/domain.py:79` | `dict` mutable, frozen dataclass ішкі dict-ті қорғамайды |
| `load_seed` сигнатурасы | ✅ | `app/core/transforms.py:83` | `str | Path` қабылдап, 6 tuple қайтарады |
| `add_reading` таза, мутациясыз | ✅ | `app/core/transforms.py:110`, `117` | `readings + (reading,)` жаңа tuple жасайды |
| `apply_calibration` таза, мутациясыз | ✅ | `app/core/transforms.py:120`, `131` | `replace` арқылы жаңа `Sensor` жасайды |
| `readings_stats` map/filter/reduce қолданады | ✅ | `app/core/transforms.py:182`, `184`, `190` | `kind` бойынша сүзу және reduce accumulator бар |
| UI Overview агрегаттары | ✅ | `app/main.py:86`, `104`, `106` | `readings_stats` арқылы temp/hum метрикалары |
| UI Data Load seed | ✅ | `app/main.py:114`, `122`, `123` | `Load seed` батырмасы seed жүктейді |
| Лаб №1 ≥5 тест | ✅ | `tests/test_lab1.py:18` | 8 мағыналы тест бар |
| `by_sensor_kind` closure | ✅ | `app/core/transforms.py:204`, `213`, `215` | `kind` және `sensors_by_id` жабылады |
| `by_location` иерархияны ескереді | ✅ | `app/core/transforms.py:219`, `231` | `collect_descendant_locations` арқылы ұрпақ location алынады |
| `by_time_range` closure және inclusive edge | ✅ | `app/core/transforms.py:249`, `257` | `start <= ts <= end` |
| ≥2 рекурсивті функция | ✅ | `app/core/recursion.py:12`, `57` | `collect_descendant_locations` және `nest_readings_by_day` тікелей рекурсивті |
| `find_sensors_in_location` рекурсияны қолданады | ✅ | `app/core/recursion.py:33`, `45` | Өзі тікелей recursive емес, бірақ recursive helper қолданады |
| Рекурсия базалық жағдайы | ✅ | `app/core/recursion.py:30`, `66`, `67` | `nest_readings_by_day` бос кірісте тоқтайды |
| Лаб №2 UI сүзгілері | ✅ | `app/main.py:210`, `212`, `215` | Сенсор түрі, локация, кезең бар |
| Лаб №2 ≥5 тест | ✅ | `tests/test_lab2.py:18` | 9 мағыналы тест бар |
| Таза функциялар | ✅ | `app/core/transforms.py:273`, `285`, `295` | Core функциялар кірісті өзгертпейді |
| Иммутабельдік: tuple/frozenset/replace | ✅ | `app/core/transforms.py:117`, `231`, `131` | Дәріс тақырыбы нақты қолданылған |
| Lambda, map/filter/reduce | ✅ | `app/core/transforms.py:30`, `282`, `190` | Кодта кең қолданылған |
| HOF, Callable/Iterable | ✅ | `app/core/transforms.py:14`, `204`, `261` | Predicate factory және generic helpers бар |
| sorted + key=lambda | ✅ | `app/core/transforms.py:349`, `350`, `355` | `sort_readings` |
| partial | ✅ | `app/main.py:10`, `237`, `238` | Pipeline ішінде аргумент бекіту |
| Каррирование | ✅ | `app/core/compose.py:43`, `51` | `curry2` |
| Декораторлар | ✅ | `app/core/compose.py:55`, `74`, `96` | `timed`, `logged`, `type_checked` |
| compose/pipe | ✅ | `app/core/compose.py:19`, `31` | Reduce арқылы іске асқан |
| Мәзірде 8 пункт | ✅ | `app/main.py:41`-`49` | Overview, Data, Functional Core, Pipelines, Async/FRP, Reports, Tests, About |
| Seed жоқ кезде беттер құламайды | ✅ | `app/main.py:73`, `82`, `94`, `142`, `205` | Overview/Functional/Pipelines `ensure_seed` қолданады |
| Pipeline бос filtered нәтиже | ✅ | `app/main.py:228`, `232`, `245`, `253` | `readings_stats`, `avg_by_sensor`, `nest_readings_by_day` бос tuple-мен жұмыс істейді |
| Pipeline бос жалпы readings | ⚠️ | `app/main.py:214`, `216` | Егер seed ішінде readings бос болса, `days[0]` құлайды |
| Қазақша UI/docstring/comment | ✅ | `app/main.py`, `app/core/*.py` | Негізінен қазақша |
| Әр файлда module docstring | ✅ | барлық `.py` | AST тексеруі бойынша жоқ docstring табылмады |
| Әр функция/класс docstring | ✅ | барлық `.py` | AST тексеруі бойынша жоқ docstring табылмады |
| README іске қосу | ✅ | `README.md:8`-`15` | PowerShell командалары бар |
| README навигация | ✅ | `README.md:26`-`37` | UI кестесі бар |
| README сигнатуралар | ✅ | `README.md:39`-`67` | Функциялар тізімі бар |
| README дәріс кестесі | ✅ | `README.md:69`-`76` | 1-4 дәріс байланысы бар |
| README қатысушылар үлесі | ⚠️ | `README.md:78`-`80` | `TODO` қалған |
| Root `.gitignore` | ❌ | жоба түбірі | Root `.gitignore` жоқ; тек `.idea/.gitignore`, `.venv/.gitignore`, cache `.gitignore` бар |
| `requirements.txt` | ✅ | `requirements.txt:1`-`4` | `streamlit`, `pytest`, `black`, `ruff` |
| `pyproject.toml` | ✅ | `pyproject.toml:1`-`14` | Black/Ruff/Pytest баптауы бар, target `py311` |

## Функционалды стиль сапасы

AST тексеруі бойынша `app/core/transforms.py`, `app/core/recursion.py`, `app/core/compose.py` ішінде төмендегілер табылмады:

| Ізделген нәрсе | Нәтиже |
|---|---|
| `for` / `while` statement | ✅ Табылмады |
| `.append()` / `.extend()` / `.sort()` / `.update()` | ✅ Табылмады |
| `global` | ✅ Табылмады |
| Subscript assignment (`x[i] = ...`) | ✅ Табылмады |

Жанама әсерлер:

| Файл:жол | Түрі | Баға |
|---|---|---|
| `app/main.py:60`, `123`, `155`, `175` | `st.session_state` оқу/жазу | UI қабатында орынды, core таза қалады |
| `scripts/generate_seed.py:179` | Файлға жазу | Генератор скрипт үшін орынды |
| `scripts/generate_seed.py:182` | `print` | CLI скрипт үшін орынды |
| `app/core/compose.py:66`-`69` | Уақыт өлшеу | `timed` decorator жанама print жасамайды, нәтиже қайтарады |

Кіріс аргументтер мутацияланбайтынын дәлелдейтін тесттер:

| Тест | Нені дәлелдейді |
|---|---|
| `tests/test_lab1.py:26` | `add_reading` бастапқы tuple ұзындығын өзгертпейді |
| `tests/test_lab1.py:37` | `apply_calibration` тек сәйкес sensor-ға жаңа мән береді |
| `tests/test_lab1.py:47` | Белгісіз sensor id кезінде мәндер сақталады |
| `tests/test_lab1.py:72` | `calibrated_readings` бастапқы Reading value мәнін өзгертпейді |
| `tests/test_lectures.py:96` | `sort_readings` бастапқы ретті өзгертпейді |

Жасырын тәуекелдер:

| Тақырып | Баға |
|---|---|
| Бос кіріс | `readings_stats`, `aggregate_data`, `nest_readings_by_day` жақсы; бірақ `page_pipelines` seed readings бос болса `days[0]` арқылы құлайды (`app/main.py:216`) |
| Белгісіз `sensor_id` | `apply_calibration` жақсы; бірақ `calibrated_readings` және `readings_stats` missing sensor кезінде `KeyError` береді (`app/core/transforms.py:165`, `185`) |
| `ts` форматы | `by_time_range` string compare қолданады (`app/core/transforms.py:257`), ISO емес форматта silently wrong болуы мүмкін |
| Дөңгелектеу | Core `avg` дөңгелектемейді, UI ғана `round(..., 2)` жасайды (`app/main.py:110`) |
| Шекаралық уақыт | Inclusive: `start <= reading.ts <= end` (`app/core/transforms.py:257`), тест бар (`tests/test_lab2.py:26`) |
| Бөлшекке бөлу | `readings_stats` count=0 болса `avg=None` (`app/core/transforms.py:200`), `avg_by_sensor` тек count бар топтарға бөледі |
| Дубликат sensor id | `_sensor_map` dict жасайды, duplicate болса соңғысы жеңеді (`app/core/transforms.py:148`) |
| Локация циклдары | `collect_descendant_locations` cycle guard жоқ, malformed hierarchy болса шексіз рекурсия қаупі бар (`app/core/recursion.py:24`-`30`) |

## Тест сапасы

| Бөлім | Сан | Баға |
|---|---:|---|
| Лаб №1 тесттері | 8 | ✅ Мағыналы, immutable/load/stats/calibration қамтылған |
| Лаб №2 тесттері | 9 | ✅ Closure, hierarchy, recursion, edge time қамтылған |
| Дәріс тесттері | 10 | ✅ compose/pipe/curry/decorator/filter-transform-aggregate қамтылған |

Қамтылған шеткі жағдайлар:

| Case | Бар ма |
|---|---|
| Бос readings stats | ✅ `tests/test_lab1.py:64` |
| Белгісіз sensor id calibration | ✅ `tests/test_lab1.py:47` |
| Бос recursion input | ✅ `tests/test_lab2.py:94` |
| Уақыт шекарасы inclusive | ✅ `tests/test_lab2.py:26` |
| Бастапқы tuple мутацияланбауы | ✅ бірнеше тест |

Жабылмаған немесе әлсіз жабылған функциялар:

| Функция | Қазіргі күй | Ұсынылатын қосымша тест |
|---|---|---|
| `_to_locations`, `_to_devices`, `_to_sensors`, `_to_readings`, `_to_rules`, `_to_alerts` | Тікелей аталмайды, `load_seed` арқылы жанама жабылған | Бір минимал JSON dict үшін нақты dataclass типтері тексерілсін |
| `_sensor_map` | Жанама жабылған | Duplicate id болса не болатынын құжаттау немесе тесттеу |
| `readings_in_range` | Тестте аталмайды | `low/high` inclusive және бос tuple case |
| `sort_readings` invalid `by` | Жоқ | `pytest.raises(KeyError)` немесе validation қосу |
| `calibrated_readings` missing sensor | Жоқ | `KeyError` күтіле ме, әлде skip керек пе, нақтылау |
| `collect_descendant_locations` cycle | Жоқ | Malformed hierarchy үшін cycle guard немесе recursion limit тесті |
| `page_pipelines` empty seed readings | Жоқ | Streamlit UI/unit тест немесе guard тест |

## UI тексеруі

| Тексеру | Күй | Дәлел |
|---|---:|---|
| Мәзірде дәл 8 пункт | ✅ | `app/main.py:41`-`49` |
| Overview seed жоқ кезде құламайды | ✅ | `ensure_seed`, `app/main.py:94`-`96` |
| Functional Core seed жоқ кезде құламайды | ✅ | `app/main.py:142`-`144` |
| Pipelines seed жоқ кезде құламайды | ✅ | `app/main.py:205`-`207` |
| Data Load seed бар | ✅ | `app/main.py:122`-`124` |
| session_state қолдану түсінікті | ✅ | `app/main.py:60`, `123`, `155`, `175` |
| Бастапқы tuple тікелей мутацияланбайды | ✅ | Жаңа tuple session_state-ке қайта қойылады |
| Filter комбинациясы бос болса құламауы | ✅ | `filtered=()` кезінде stats/avg/day grouping жұмыс істейді |
| Seed readings толық бос болса | ⚠️ | `days[0]`, `days[-1]` guard жоқ (`app/main.py:216`) |
| UI мәтіні қазақша | ✅ | Негізгі мәтіндер қазақша |

Streamlit smoke test нәтижесі: сервер іске қосылды, browser URL шығарды, `Traceback` табылмады.

## Құжаттама және түсініктеме

| Талап | Күй | Түсініктеме |
|---|---:|---|
| Module docstring | ✅ | Барлық `.py` файлда бар |
| Function/class docstring | ✅ | AST тексеруі бойынша жоқ docstring табылмады |
| Lambda/reduce/recursion/closure түсініктемелері | ✅ | Core файлдарда қысқа түсініктемелер жеткілікті |
| README іске қосу | ✅ | `README.md:8`-`15` |
| README тексеру командалары | ✅ | `README.md:17`-`24` |
| README навигация | ✅ | `README.md:26`-`37` |
| README сигнатуралар | ✅ | `README.md:39`-`67` |
| README дәріс кестесі | ✅ | `README.md:69`-`76` |
| README қатысушылар үлесі | ⚠️ | `README.md:80` -> `TODO` |

## Орнату және құрылым

| Тексеру | Күй | Түсініктеме |
|---|---:|---|
| Негізгі құрылым | ✅ | `app/core`, `app/main.py`, `data`, `scripts`, `tests` бар |
| PDF каркасы | ⚠️ | Репода PDF жоқ, сондықтан 100% салыстыру жасалмады |
| `requirements.txt` | ✅ | Минималды тәуелділіктер бар |
| `pyproject.toml` | ✅ | Black/Ruff/Pytest бапталған |
| Python 3.11-3.14 | ✅/⚠️ | `target-version = py311`, smoke test Python 3.14-та өтті; Streamlit нұсқасы requirements-та pin емес |
| Root `.gitignore` | ❌ | Жоба түбірінде жоқ; `.venv`, `__pycache__`, `.idea` root деңгейде ескерілмеген |

## Табылған қателер

### 1. Ruff quality gate құлайды

Ауырлығы: **Орташа**  
Файл:жол: `app/core/compose.py:74`, `app/core/compose.py:88`, `app/core/recursion.py:26`, `app/core/transforms.py:201`, `app/core/transforms.py:292`, `app/main.py:173`, `174`, `212`, `213`, `223`, `237`, `245`, `tests/test_lab2.py:29`, `tests/test_lectures.py:23`, `24`, `33`

Не қате: `ruff check .` 16 error береді: ұзын жолдар және lambda-ны айнымалыға беру (`E731`).

Қалай түзету:

```python
def double(value):
    return value * 2

def inc(value):
    return value + 1
```

Ұзын жолдарды Black форматымен немесе қолмен бірнеше жолға бөлу керек.

### 2. Black format gate құлайды

Ауырлығы: **Орташа**  
Файл:жол: `tests/__init__.py`, `app/core/recursion.py`, `app/core/compose.py`, `tests/test_lab2.py`, `app/main.py`, `app/core/transforms.py`

Не қате: `black --check .` 6 файлды қайта форматтау керек дейді.

Қалай түзету:

```powershell
.\.venv\Scripts\python.exe -m black .
.\.venv\Scripts\python.exe -m ruff check .
```

### 3. Root `.gitignore` жоқ

Ауырлығы: **Орташа**  
Файл:жол: жоба түбірі

Не қате: түбірде `.gitignore` жоқ, сондықтан `.venv`, `.idea`, `__pycache__`, cache файлдар репоға кіріп кетуі мүмкін.

Қалай түзету:

```gitignore
.venv/
__pycache__/
*.py[cod]
.pytest_cache/
.ruff_cache/
.idea/
```

### 4. `Rule.payload` толық immutable емес

Ауырлығы: **Жеңіл**  
Файл:жол: `app/core/domain.py:79`

Не қате: `Rule` frozen болғанымен, `payload` ішіндегі `dict` mutable.

Қалай түзету:

```python
from types import MappingProxyType

payload = MappingProxyType(dict(payload))
```

Немесе нақты rule payload үшін жеке frozen dataclass модельдерін енгізу.

### 5. Missing sensor id кезінде `KeyError`

Ауырлығы: **Орташа**  
Файл:жол: `app/core/transforms.py:165`, `185`

Не қате: `calibrated_readings` және `readings_stats` `sensors_by_id[reading.sensor_id]` деп тікелей алады. Егер reading ішінде белгісіз `sensor_id` болса, функция құлайды.

Қалай түзету:

```python
sensor = sensors_by_id.get(reading.sensor_id)
if sensor is None:
    return reading
```

Немесе бұл жағдайды әдейі `KeyError` деп құжаттап, тест қосу керек.

### 6. Локация иерархиясында цикл болса шексіз рекурсия қаупі бар

Ауырлығы: **Орташа**  
Файл:жол: `app/core/recursion.py:24`-`30`

Не қате: `collect_descendant_locations` malformed cyclic data үшін visited set қолданбайды.

Қалай түзету:

```python
def collect_descendant_locations(locations, root_id, seen=frozenset()):
    if root_id in seen:
        return ()
    seen = seen | {root_id}
    ...
```

### 7. Pipeline seed readings бос болса құлайды

Ауырлығы: **Жеңіл**  
Файл:жол: `app/main.py:214`-`216`

Не қате: `days[0]` және `days[-1]` бос readings кезінде `IndexError` береді.

Қалай түзету:

```python
if not days:
    st.info("Көрсеткіштер жоқ.")
    return
```

### 8. README-де қатысушылар үлесі толтырылмаған

Ауырлығы: **Жеңіл**  
Файл:жол: `README.md:78`-`80`

Не қате: `- TODO` қалған.

Қалай түзету:

```markdown
## Қатысушылар үлесі

- Аты-жөні: domain, transforms, UI, tests, README.
```

## Қорғауда сұралуы мүмкін әлсіз жерлер

| Әлсіз жер | Қысқа жауап |
|---|---|
| Неге `ruff` және `black` құлап тұр? | Функционал дұрыс, бірақ формат/линт gate толық жабылмаған; Black форматтау және lambda assignment түзету керек |
| `Rule.payload` immutable емес қой? | Иә, бұл икемді rule параметрлері үшін қалдырылған; production-та mapping proxy немесе frozen payload model қолданар едім |
| `readings_stats` сигнатурасында неге `sensors` бар? | `Reading` ішінде `kind` жоқ, нормализация бойынша kind `Sensor` ішінде сақталған |
| `load_seed` таза функция ма? | Толық таза емес, себебі файл оқиды; бірақ I/O шекарада, core transformation tuple-мен таза жұмыс істейді |
| Локацияда цикл болса не болады? | Қазіргі seed ағаш тәрізді, бірақ жалпы жағдайда visited guard керек |
| Async/FRP және Reports неге толық емес? | Бұл Лаб 1-2 көлемі; мәзірде кейінгі бөлімдер placeholder ретінде қалдырылған |
| Неге requirements pin емес? | Қарапайым оқу жобасы үшін жеткілікті, бірақ reproducible build үшін version pin керек |
| Root `.gitignore` неге жоқ? | Бұл репо тазалығы бойынша кемшілік; қорғауға дейін қосқан дұрыс |

## Түзету жоспары

1. `python -m black .` жүргізіп, формат gate-ті жасыл қылу.
2. `tests/test_lectures.py` ішіндегі lambda assignment-тарды `def` функцияларға ауыстыру.
3. `python -m ruff check .` қайта жүргізіп, барлық `E501/E731` мәселесін жабу.
4. Root `.gitignore` қосу: `.venv/`, `__pycache__/`, `.pytest_cache/`, `.ruff_cache/`, `.idea/`.
5. `README.md` ішіндегі қатысушылар үлесін толтыру.
6. `page_pipelines` ішінде бос `days` guard қосу.
7. `calibrated_readings` және `readings_stats` үшін missing sensor id behavior-ын нақтылау: не `KeyError` тесті, не graceful skip.
8. `collect_descendant_locations` үшін cycle guard немесе malformed hierarchy тестін қосу.
9. `readings_in_range`, invalid `sort_readings(by=...)`, duplicate sensor id үшін қосымша тест жазу.
10. `requirements.txt` нұсқаларын pin ету немесе README-де тексерілген нұсқаларды көрсету.

