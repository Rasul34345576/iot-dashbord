# Қорғауға дайындық: «Климат/IoT датчиктерінің дашборды»

Бұл файл жобаны оқытушыға қысқа әрі нақты түсіндіруге арналған. Жоба Python + Streamlit арқылы жасалған, негізгі акцент функционалды бағдарламалау (functional programming, FP): таза функциялар, өзгермейтіндік, `map/filter/reduce`, `lambda`, рекурсия, тұйықталу (замыкание, closure), жоғары ретті функциялар (HOF), `partial`, каррирование және декораторлар.

Ескерту: репо ішінде Лаб №1-2 PDF файлы табылмады, сондықтан «PDF-тегі приёмка» толық құжатпен салыстырылмады. Төмендегі тексеру README, тесттер және кодта көрінетін талаптар бойынша жасалды.

## 1. Жоба картасы

| Файл | Не істейді | Лаба/дәріс байланысы |
|---|---|---|
| `app/__init__.py` | `app` папкасын Python пакет ретінде белгілейді. | Streamlit қолданбасын модуль ретінде іске қосуға көмектеседі. |
| `app/core/__init__.py` | `app.core` пакетін белгілейді. | Лаб 1-2 ядро модульдерін жинақтау. |
| `app/core/domain.py` | `Location`, `Device`, `Sensor`, `Reading`, `Rule`, `Alert` frozen dataclass модельдерін анықтайды. | Лаб 1, Дәріс 3: өзгермейтіндік (immutability). |
| `app/core/transforms.py` | JSON оқу, tuple-ға айналдыру, статистика, сүзу, сұрыптау, top-n, closure-предикаттар. | Лаб 1-2, Дәріс 1-4: таза функция, map/filter/reduce, lambda, HOF, closure. |
| `app/core/recursion.py` | Локация ұрпақтарын және күн бойынша топтауды рекурсиямен жасайды. | Лаб 2, Дәріс 2: рекурсия, filter/reduce. |
| `app/core/compose.py` | `compose`, `pipe`, `curry2`, `timed`, `logged`, `type_checked`. | Дәріс 4: HOF, partial/curry, decorator. |
| `app/main.py` | Streamlit UI: Data, Overview, Functional Core, Pipelines, Tests, About беттері. | Лаб 1-2 демонстрациясы, Дәріс 1-4 ұғымдарын UI-да көрсету. |
| `data/seed.json` | Демо дерек: `locations`, `devices`, `sensors`, `readings`, `rules`, `alerts`. | Лаб 1 дерек моделі және көлем талабы. |
| `scripts/generate_seed.py` | `seed.json` файлын детерминді генерациялайды (`random.seed(42)`). | Лаб 1-2: бастапқы дерек дайындау. |
| `tests/conftest.py` | Ортақ fixture: locations/devices/sensors/readings. | Тест инфрақұрылымы. |
| `tests/test_lab1.py` | Immutable модельдер, add/calibration/stats/load seed тесттері. | Лаб 1 қабылдау тесттері. |
| `tests/test_lab2.py` | Closure, иерархиялық сүзу, рекурсия тесттері. | Лаб 2 қабылдау тесттері. |
| `tests/test_lectures.py` | Compose/pipe/curry/decorator/filter-transform-aggregate тесттері. | Дәріс 1-4 ұғымдарын тексеру. |
| `tests/__init__.py` | `tests` папкасын Python пакет ретінде белгілейді. | Pytest тесттерін пакет ішінде ұстау. |
| `README.md` | Іске қосу, навигация, функция сигнатуралары. | Қорғаудағы қысқа нұсқаулық. |
| `requirements.txt` | Тәуелділіктер: Streamlit, pytest, black, ruff. | Орнату және тексеру. |
| `pyproject.toml` | Black/Ruff/Pytest баптауы. | Сапа және тест конфигурациясы. |

## 2. Функциялар бойынша шпаргалка

### `domain.py`

`domain.py` ішінде функция жоқ, бірақ негізгі dataclass модельдері бар:

| Класс, жол | Не істейді | Кіріс -> шығыс | FP ұғымы | Қорғауда айтуға жауап |
|---|---|---|---|---|
| `Location`, `domain.py:13` | Локация түйінін сақтайды: кампус, ғимарат, қабат, бөлме. | `id: str, name: str, parent_id: str | None` -> `Location` | өзгермейтіндік, frozen dataclass | Локацияны кейін кездейсоқ өзгертіп қоймау үшін `frozen=True` қолдандым. |
| `Device`, `domain.py:26` | Құрылғыны локациямен байланыстырады. | `id, location_id, model, firmware: str` -> `Device` | өзгермейтіндік | Device бастапқы дерек ретінде тұрақты қалады. |
| `Sensor`, `domain.py:40` | Температура/ылғал сенсорын және calibration мәнін сақтайды. | `id, device_id, kind, unit, calibration` -> `Sensor` | Literal type, immutability | Calibration өзгерсе, ескі объект емес, жаңа Sensor жасалады. |
| `Reading`, `domain.py:55` | Бір уақыттағы сенсор өлшемін сақтайды. | `id, sensor_id, ts, value` -> `Reading` | immutable data | Reading өлшемдері бастапқы журнал сияқты өзгермеуі керек. |
| `Rule`, `domain.py:69` | Range/delta/stale ережелерін сақтайды. | `id, kind, payload: dict` -> `Rule` | partial immutability | Класс frozen, бірақ `payload` dict толық immutable емес, бұл әлсіз жер. |
| `Alert`, `domain.py:82` | Ескерту оқиғасын сақтайды. | `id, ts, sensor_id, location_id, code, message, severity` -> `Alert` | immutable event | Alert журнал жазбасы ретінде өзгеріссіз сақталады. |

### `transforms.py`

| Функция, жол | Не істейді | Кіріс -> шығыс | FP ұғымы | Қорғауда айтуға жауап |
|---|---|---|---|---|
| `_to_locations`, `transforms.py:23` | JSON dict тізімін `Location` tuple-ына айналдырады. | `Iterable[dict]` -> `tuple[Location, ...]` | map, lambda, таза түрлендіру | Бірдей түрлендіруді әр элементке `map` арқылы қолдандым. |
| `_to_devices`, `transforms.py:33` | JSON dict-терден `Device` tuple жасайды. | `Iterable[dict]` -> `tuple[Device, ...]` | map, lambda | Шығыс tuple болғандықтан бастапқы list мутацияланбайды. |
| `_to_sensors`, `transforms.py:43` | JSON dict-терден `Sensor` tuple жасайды. | `Iterable[dict]` -> `tuple[Sensor, ...]` | map, immutability | Сенсорлар tuple ішінде сақталып, кездейсоқ өзгеріс азаяды. |
| `_to_readings`, `transforms.py:53` | JSON көрсеткіштерін `Reading` tuple-ына айналдырады. | `Iterable[dict]` -> `tuple[Reading, ...]` | map, lambda | Reading объектілері есептеу үшін типтелген модельге айналады. |
| `_to_rules`, `transforms.py:63` | JSON ережелерін `Rule` tuple-ына айналдырады. | `Iterable[dict]` -> `tuple[Rule, ...]` | map | Rule payload әртүрлі болғандықтан dict ретінде қалды. |
| `_to_alerts`, `transforms.py:73` | JSON alert жазбаларын `Alert` tuple-ына айналдырады. | `Iterable[dict]` -> `tuple[Alert, ...]` | map | Alert журналын immutable объектілер ретінде қолданамын. |
| `load_seed`, `transforms.py:83` | `seed.json` оқып, барлық бөлімді tuple-мен қайтарады. | `str | Path` -> `(locations, devices, sensors, readings, rules, alerts)` | тазаға жақын функция, immutable output | Файл оқу side effect, бірақ оқылғаннан кейін дерек tuple түрінде қауіпсіз беріледі. |
| `add_reading`, `transforms.py:110` | readings соңына жаңа Reading қосылған жаңа tuple қайтарады. | `tuple[Reading, ...], Reading` -> `tuple[Reading, ...]` | таза функция, tuple immutability | Ескі readings өзгермейді, жаңа tuple қайтады. |
| `apply_calibration`, `transforms.py:120` | Таңдалған сенсор calibration мәнін жаңа Sensor арқылы өзгертеді. | `tuple[Sensor, ...], str, float` -> `tuple[Sensor, ...]` | map, lambda, immutability, replace | Frozen объектіні бұзбай, `replace` арқылы жаңа объект жасаймын. |
| `_sensor_map`, `transforms.py:141` | Sensor id бойынша жылдам іздеу dict жасайды. | `Iterable[Sensor]` -> `dict[str, Sensor]` | map, pure helper | Reading ішінде kind жоқ, сондықтан sensor id арқылы табамыз. |
| `calibrated_readings`, `transforms.py:151` | Reading value-сына sensor calibration қосып, жаңа Reading tuple қайтарады. | `tuple[Reading, ...], tuple[Sensor, ...]` -> `tuple[Reading, ...]` | map, lambda, replace, pure projection | Бастапқы өлшем өзгермейді, тек калибрленген проекция көрсетіледі. |
| `readings_stats`, `transforms.py:172` | Берілген kind үшін min/max/avg/count есептейді. | `readings, sensors, kind: str` -> `dict[str, float | int | None]` | filter, map, reduce, accumulator | Sensor kind readings ішінде жоқ болғандықтан sensors параметрі қосылды. |
| `by_sensor_kind`, `transforms.py:204` | kind бойынша сүзетін predicate қайтарады. | `kind: str, sensors` -> `Callable[[Reading], bool]` | closure, HOF | `kind` пен sensor map ішкі lambda ішінде есте сақталады. |
| `by_location`, `transforms.py:219` | Иерархиялық локация бойынша predicate қайтарады. | `location_id, locations, devices, sensors` -> `Callable[[Reading], bool]` | closure, recursion қолдану, frozenset | Алдымен барлық ұрпақ location табылады, кейін sensor id жиыны арқылы сүзеді. |
| `by_time_range`, `transforms.py:249` | Уақыт аралығын қоса тексеретін predicate қайтарады. | `start: str, end: str` -> `Callable[[Reading], bool]` | closure, lambda | ISO уақыт жолы болғандықтан лексикографиялық салыстыру жұмыс істейді. |
| `all_of`, `transforms.py:261` | Бірнеше predicate-ті AND ретінде біріктіреді. | `*Callable` -> `Callable[[Reading], bool]` | HOF, map, all | Бірнеше шартты бір предикатқа жинаймын. |
| `select`, `transforms.py:273` | Predicate бойынша readings сүзеді. | `tuple[Reading, ...], Callable` -> `tuple[Reading, ...]` | filter, pure function | Сүзу жаңа tuple қайтарады. |
| `filter_data`, `transforms.py:285` | Кез келген iterable-ды condition бойынша сүзеді. | `Iterable[T], Callable[[T], bool]` -> `tuple[T, ...]` | filter, generic HOF | Жалпы pipeline мысалы үшін универсал функция. |
| `transform_data`, `transforms.py:295` | Кез келген iterable элементін transformer арқылы түрлендіреді. | `Iterable[T], Callable[[T], U]` -> `tuple[U, ...]` | map, HOF | Бір функцияны барлық элементке қолданады. |
| `aggregate_data`, `transforms.py:305` | Iterable мәндерін бір мәнге жинайды. | `Iterable[T], Callable[[T,T],T]` -> `T | None` | reduce, accumulator | Бос кірісте қате емес, `None` қайтарады. |
| `in_range`, `transforms.py:316` | value диапазоны predicate-ін жасайды. | `low: float, high: float` -> `Callable[[Reading], bool]` | closure, lambda | `low/high` мәндері closure ішінде сақталады. |
| `readings_in_range`, `transforms.py:328` | readings-ті value диапазоны бойынша сүзеді. | `readings, low, high` -> `tuple[Reading, ...]` | function reuse, closure | Нақты жұмысты `in_range` және `select` орындайды. |
| `sort_readings`, `transforms.py:340` | readings-ті `ts`, `value`, `sensor` бойынша сұрыптайды. | `readings, by: str, reverse: bool` -> `tuple[Reading, ...]` | sorted, lambda key, immutability | `sorted` жаңа list береді, оны tuple-ға айналдырамын. |
| `top_n_readings`, `transforms.py:359` | Ең үлкен value бар алғашқы n Reading қайтарады. | `readings, n: int` -> `tuple[Reading, ...]` | композиция, slice | Алдымен сұрыптап, кейін алғашқы n элементті аламын. |
| `avg_by_sensor`, `transforms.py:369` | Әр sensor_id бойынша орташа value есептейді. | `tuple[Reading, ...]` -> `tuple[tuple[str, float], ...]` | reduce, map, accumulator | Accumulator sum/count сақтап, соңында avg есептейді. |

### `recursion.py`

| Функция, жол | Не істейді | Кіріс -> шығыс | FP ұғымы | Қорғауда айтуға жауап |
|---|---|---|---|---|
| `collect_descendant_locations`, `recursion.py:12` | Root location және барлық ұрпақ location id қайтарады. | `tuple[Location, ...], root_id: str` -> `tuple[str, ...]` | рекурсия, filter, reduce | Базалық жағдай: бала жоқ болса `child_ids=()`, тек root қайтады. |
| `find_sensors_in_location`, `recursion.py:33` | Локация тармағындағы сенсорларды табады. | `locations, devices, sensors, root_id` -> `tuple[Sensor, ...]` | recursion reuse, filter, map | Алдымен location ұрпақтары, кейін device және sensor байланысы сүзілді. |
| `nest_readings_by_day`, `recursion.py:57` | readings-ті күн бойынша рекурсивті топтайды. | `tuple[Reading, ...]` -> `tuple[(day, tuple[Reading, ...]), ...]` | рекурсия, filter, immutable tuple | Бос readings болса `()` қайтып, рекурсия тоқтайды. |

### `compose.py`

| Функция, жол | Не істейді | Кіріс -> шығыс | FP ұғымы | Қорғауда айтуға жауап |
|---|---|---|---|---|
| `compose`, `compose.py:19` | Функцияларды оңнан солға біріктіреді. | `*Callable` -> `Callable` | HOF, reduce, composition | `compose(f, g)(x)` математикалық `f(g(x))` сияқты. |
| `pipe`, `compose.py:31` | Мәнді функциялар тізбегінен солдан оңға өткізеді. | `value, *Callable` -> соңғы нәтиже | HOF, reduce, pipeline | UI-дағы filter -> sort -> top-n қадамын оқуға жеңіл етеді. |
| `curry2`, `compose.py:43` | Екі аргументті функцияны бір-бір аргумент қабылдайтын функцияларға бөледі. | `Callable[[T,U],V]` -> `Callable[[T], Callable[[U], V]]` | каррирование, closure | Бірінші аргумент ішкі lambda ішінде сақталады. |
| `timed`, `compose.py:55` | Функция нәтижесі мен орындалу уақытын қайтаратын decorator. | `Callable[..., T]` -> `Callable[..., tuple[T, float]]` | decorator, wraps, HOF | `print` жасамай, өлшеу нәтижесін UI/тестке таза қайтарады. |
| `logged`, `compose.py:74` | Сырттан берілген sink арқылы функция атауын логтайтын decorator factory. | `Callable[[str], None]` -> decorator | decorator, closure, dependency injection | Лог қайда жазылатынын сырттан береміз, тесттеу оңай. |
| `type_checked`, `compose.py:96` | Нәтиже типін тексеретін decorator factory. | `type` -> decorator | decorator, closure, TypeError | Қате типті ерте ұстайды. |

## 3. Лаб бойынша тексеру тізімі

PDF табылмағандықтан, нақты acceptance ретінде README мен тест атауларындағы талаптар алынды.

| Талап | Қай файл/функция орындайды | UI-да қайдан көруге болады | Қай тест тексереді | Күйі |
|---|---|---|---|---|
| Домен модельдері immutable болуы | `domain.py:13`, `26`, `40`, `55`, `69`, `82` | Data бөлімінде объектілер tuple ретінде көрсетіледі | `test_lab1.py:18` | Орындалды |
| Жаңа reading қосқанда бастапқы tuple өзгермеуі | `add_reading`, `transforms.py:110` | Functional Core -> «Көрсеткіш қосу» | `test_lab1.py:26` | Орындалды |
| Calibration қолдану immutable болуы | `apply_calibration`, `transforms.py:120` | Functional Core -> «Калибрлеуді қолдану» | `test_lab1.py:37`, `47` | Орындалды |
| Калибрленген проекция жасау | `calibrated_readings`, `transforms.py:151` | Functional Core -> «Калибрленген проекция» | `test_lab1.py:72` | Орындалды |
| Temp/hum статистикасы | `readings_stats`, `transforms.py:172` | Overview және Pipelines | `test_lab1.py:56`, `64` | Орындалды |
| Seed көлемі жеткілікті болуы | `generate_seed.py:15`, `load_seed`, `transforms.py:83` | Data -> Load seed | `test_lab1.py:82` | Орындалды: 27/12/24/1440/5/2 |
| Lambda және kind бойынша сүзу | `by_sensor_kind`, `transforms.py:204` | Pipelines -> «Сенсор түрі» | `test_lab2.py:18` | Орындалды |
| Уақыт аралығы бойынша сүзу | `by_time_range`, `transforms.py:249` | Pipelines -> «Кезең» | `test_lab2.py:26` | Орындалды |
| Локация иерархиясын ескеру | `by_location`, `transforms.py:219`; `collect_descendant_locations`, `recursion.py:12` | Pipelines -> «Иерархиядағы ішкі локацияларды қоса алу» | `test_lab2.py:34`, `65` | Орындалды |
| Бірнеше predicate біріктіру | `all_of`, `transforms.py:261` | Pipelines сүзгілері бірге жұмыс істейді | `test_lab2.py:53` | Орындалды |
| Рекурсия арқылы топтау | `nest_readings_by_day`, `recursion.py:57` | Pipelines -> «Күн бойынша рекурсивті топтау» | `test_lab2.py:81`, `94` | Орындалды |
| compose/pipe/curry/decorator | `compose.py` | Functional Core және Pipelines | `test_lectures.py:20`, `30`, `39`, `48`, `64` | Орындалды |
| Async/FRP және Reports толық болуы | `page_later`, `main.py:259` | Async/FRP, Reports | Тест жоқ | Әлсіз: тек заглушка |

Тест нәтижесі: `.\.venv\Scripts\python.exe -m pytest -q` -> `27 passed in 0.14s`.

## 4. Дәріс 1-4 -> код

| Ұғым | Қысқа анықтама | Кодтан мысал | Неге осылай жасалған |
|---|---|---|---|
| Таза функция (pure function) | Бірдей кіріске бірдей шығыс береді, сыртқы күйді өзгертпейді. | `add_reading`, `transforms.py:110` | Ескі readings өзгермей, жаңа tuple қайтады. |
| Өзгермейтіндік (immutability) | Дерек құрылғаннан кейін өзгермейді. | `@dataclass(frozen=True)`, `domain.py:13` | Домен объектілерін кездейсоқ бұзбау үшін. |
| Tuple қолдану | Өзгермейтін коллекция. | `load_seed`, `transforms.py:100` | JSON list-терін қауіпсіз tuple-ға ауыстырады. |
| `map` | Бір функцияны барлық элементке қолданады. | `_to_locations`, `transforms.py:30` | Dict-терді dataclass объектілеріне айналдыруға ыңғайлы. |
| `filter` | Шартқа сай элементтерді ғана қалдырады. | `select`, `transforms.py:282` | Predicate арқылы жалпы сүзу жасалады. |
| `reduce` | Бірнеше мәнді бір accumulator мәнге жинайды. | `readings_stats`, `transforms.py:190` | Min/max/sum/count бір жүріспен есептеледі. |
| `lambda` | Қысқа аноним функция. | `sort_readings`, `transforms.py:350` | `key` функцияларын қысқа жазуға болады. |
| Рекурсия | Функция өз-өзін шақырады. | `collect_descendant_locations`, `recursion.py:24` | Локация ағашының тереңдігі алдын ала белгісіз. |
| Тұйықталу (closure) | Ішкі функция сыртқы айнымалыны есте сақтайды. | `by_time_range`, `transforms.py:256` | `start/end` predicate ішінде сақталады. |
| HOF | Функцияны аргумент ретінде алады немесе қайтарады. | `all_of`, `transforms.py:261` | Бірнеше predicate-ті біріктіреді. |
| `partial` | Бірнеше аргументтің бір бөлігін алдын ала бекітеді. | `main.py:237` | `pipe` ішінде `sort_readings` параметрлерін бекіту үшін. |
| Каррирование (currying) | Көп аргументті функцияны бір аргументті функциялар тізбегіне бөлу. | `curry2`, `compose.py:43` | FP-дегі функцияны ішінара қолдануды көрсету үшін. |
| Декоратор | Функцияны орап, мінезін кеңейтеді. | `timed`, `compose.py:55` | Нәтижені өзгертпей, уақыт өлшеу қосылады. |
| `Callable` | Шақырылатын функция типін көрсетеді. | `by_sensor_kind`, `transforms.py:206` | Predicate қайтатынын типпен анық көрсетеді. |
| `Iterable` | Біртіндеп оқылатын коллекция типі. | `_to_locations`, `transforms.py:23` | List қана емес, кез келген iterable қабылдайды. |

## 5. Демо сценарийі, 3-4 минут

1. **Іске қосу.** PowerShell-де README бойынша `.\.venv\Scripts\python.exe -m streamlit run app/main.py` іске қосамын. Айтамын: «Бұл Streamlit дашборд климат/IoT датчиктерінің дерегін функционалды стильде өңдейді».
2. **Data -> Load seed.** Data бетіне өтіп, `Load seed` басамын. Айтамын: «JSON ішіндегі list-тер `load_seed` арқылы tuple және frozen dataclass объектілеріне айналады».
3. **Data кестелері.** `locations`, `devices`, `sensors`, `readings`, `rules`, `alerts` expander-лерін көрсетемін. Айтамын: «Seed құрылымы толық: 27 локация, 12 құрылғы, 24 сенсор, 1440 reading, 5 rule, 2 alert».
4. **Overview.** Overview бетінде санақ пен temp/hum статистикасын көрсетемін. Айтамын: «Статистика `readings_stats` арқылы `filter/map/reduce` негізінде есептеледі».
5. **Functional Core -> add_reading.** Сенсор таңдап, мән енгізіп, «Көрсеткіш қосу» басамын. Айтамын: «`add_reading` ескі tuple-ды өзгертпейді, соңына жаңа Reading бар жаңа tuple қайтарады».
6. **Functional Core -> calibration.** Сенсор таңдап, delta қосамын. Айтамын: «`apply_calibration` frozen Sensor-ды тікелей өзгертпей, `dataclasses.replace` арқылы жаңа Sensor жасайды».
7. **Functional Core -> timed.** Калибрленген проекция мен уақытты көрсетемін. Айтамын: «`timed` decorator функцияны орап, нәтиже мен миллисекундты қайтарады».
8. **Functional Core -> sort/top-5.** Сұрыптау өрісін өзгертіп, top-5 көрсетемін. Айтамын: «`sort_readings` lambda key қолданады, `top_n_readings` сұрыпталған tuple-дың алғашқы 5 мәнін алады».
9. **Pipelines -> сүзгілер.** Kind, локация, уақыт диапазонын таңдаймын. Айтамын: «Мұнда predicate-тер closure ретінде жасалып, `all_of` арқылы бірігеді».
10. **Pipelines -> иерархия.** Include children қосулы екенін көрсетемін. Айтамын: «`by_location` алдымен рекурсиямен барлық ішкі локацияны табады, содан кейін сол тармақтағы сенсор readings-ін өткізеді».
11. **Pipelines -> pipe+partial.** Top нәтижені көрсетемін. Айтамын: «`pipe` деректі солдан оңға өткізеді, ал `partial` sort және top-n параметрлерін алдын ала бекітеді».
12. **Tests.** Tests бетінде командаларды көрсетемін. Айтамын: «Жоба 27 pytest тестімен тексерілген».

## 6. Оқытушының ықтимал сұрақтары мен жауаптары

1. **Неге `dataclass(frozen=True)` қолдандың?** Объект өрістерін кейін өзгертуге болмайды, бұл immutable дерек береді; мысал `domain.py:13`, тест `test_lab1.py:18`.
2. **Tuple мен list айырмашылығы қандай?** Tuple өзгермейді, list өзгереді; `add_reading` tuple concat жасап жаңа tuple қайтарады, `transforms.py:117`.
3. **Таза функция деген не?** Сыртқы күйді өзгертпей, кірістен шығыс жасайды; `readings_in_range`, `transforms.py:337`.
4. **Қай функция таза?** `select` тек readings пен predicate алып, жаңа tuple қайтарады; `transforms.py:273`.
5. **`load_seed` толық таза ма?** Жоқ, ол файл оқиды, яғни I/O бар; бірақ шыққан дерек tuple болады, `transforms.py:99`.
6. **Замыкание қайда?** `by_sensor_kind` сырттағы `kind` пен `sensors_by_id` мәндерін lambda ішінде сақтайды, `transforms.py:213`.
7. **`by_location` иерархияны қалай ескереді?** `collect_descendant_locations` барлық ұрпақ location id жинайды, кейін device/sensor id арқылы сүзеді, `transforms.py:231`.
8. **Рекурсияның базалық жағдайы қайсы?** `nest_readings_by_day` үшін `len(readings) == 0` болса `()` қайтады, `recursion.py:66`.
9. **`collect_descendant_locations` қашан тоқтайды?** Балалар жоқ болса reduce бос tuple береді, соңында тек root қайтады, `recursion.py:30`.
10. **Reduce accumulator қалай жұмыс істейді?** `readings_stats` ішінде acc dict min/max/sum/count сақтайды, әр value келген сайын жаңа dict жасайды, `transforms.py:190`.
11. **`readings_stats` неге `sensors` параметрін алады?** `Reading` ішінде `kind` жоқ, kind-ті `sensor_id` арқылы Sensor-дан табамыз, `transforms.py:181`.
12. **`compose` пен `pipe` айырмашылығы?** `compose` оңнан солға, `pipe` солдан оңға орындайды; `compose.py:26`, `compose.py:38`.
13. **Декоратор қалай жұмыс істейді?** `timed` функцияны `wrapper` ішінде шақырып, нәтиже мен уақыт қайтарады, `compose.py:62`.
14. **`functools.wraps` не үшін?** Оралған функцияның атауы мен metadata-сын сақтайды; `compose.py:62`, `compose.py:84`, `compose.py:108`.
15. **`partial` пен каррирование айырмашылығы?** `partial` дайын құралмен аргумент бекітеді, `curry2` функцияны nested lambda-ға бөледі; `main.py:237`, `compose.py:50`.
16. **`sorted key=lambda` қалай жұмыс істейді?** Әр Reading үшін салыстыру кілтін береді: ts/value/sensor; `transforms.py:349`.
17. **Неге бастапқы деректі мутацияламаймыз?** Тесттеу жеңіл, side effect аз, UI-де ескі және жаңа мәнді салыстыруға болады; `test_lab1.py:31`.
18. **`map` пен list comprehension айырмашылығы?** Екеуі де түрлендіреді, бірақ бұл жобада FP тақырыбын көрсету үшін `map(lambda...)` қолданылған; `transforms.py:30`.
19. **`filter` қайда қолданылған?** `select` ішінде predicate бойынша readings сүзеді, `transforms.py:282`.
20. **`all_of` не істейді?** Бірнеше predicate бәрі True болғанда ғана True қайтарады, `transforms.py:268`.
21. **`frozenset` не үшін?** Іздеу жылдам және immutable болсын деп location/device/sensor id жиындарына қолданылған, `transforms.py:231`.
22. **Калибрлеу бастапқы reading-ті өзгерте ме?** Жоқ, `calibrated_readings` `replace` арқылы жаңа Reading жасайды, `transforms.py:163`.
23. **Seed қалай генерацияланады?** `scripts/generate_seed.py` ішінде `build_seed` 3 кампус, бөлмелер, құрылғылар, сенсорлар және 60 сағат reading жасайды, `generate_seed.py:15`.
24. **Тесттер не тексереді?** Lab1 immutable/stats/seed, Lab2 closure/recursion, lectures compose/decorator; мысал `test_lectures.py:20`.
25. **UI-де FP қай жерде көрінеді?** Functional Core және Pipelines беттерінде: add/calibration/timed/pipe/partial, `main.py:134`, `main.py:197`.
26. **Неге ISO уақытты string ретінде салыстыруға болады?** Формат `YYYY-MM-DDTHH:MM:SS`, сондықтан дұрыс форматта лексикографиялық рет уақыт ретімен сәйкес келеді; `transforms.py:256`.
27. **`aggregate_data` бос кірісте не қайтарады?** `None`, себебі reduce бос iterable-да бастапқы мәнсіз қате береді; `transforms.py:312`.
28. **`Rule.payload` неге әлсіз?** Ол `dict`, dict mutable; frozen dataclass тек өрісті ауыстыруға тыйым салады, ішкі dict-ті толық қорғамайды, `domain.py:79`.
29. **Async/FRP дайын ба?** Жоқ, UI-де заглушка ғана бар, `main.py:259`; бұл Лаб 1-2 көлемінен тыс.
30. **Жоба қалай тексерілді?** `pytest -q` орындалды, нәтиже 27 тест өтті.

## 7. «Кодты тікелей жазып көрсет» тапсырмалары

### 1) Жұп сандар квадраттарының қосындысы

```python
from functools import reduce

nums = (1, 2, 3, 4, 5, 6)
result = reduce(
    lambda acc, value: acc + value,
    map(lambda value: value * value, filter(lambda value: value % 2 == 0, nums)),
    0,
)
```

Түсіндірме: алдымен жұптарды сүземіз, кейін квадраттаймыз, соңында қосамыз.

### 2) Замыкание-фабрика

```python
def greater_than(limit):
    return lambda value: value > limit

over_10 = greater_than(10)
result = tuple(filter(over_10, (3, 12, 8, 20)))
```

Түсіндірме: `limit` ішкі lambda ішінде есте сақталады.

### 3) Рекурсивті факториал

```python
def factorial(n):
    if n == 0:
        return 1
    return n * factorial(n - 1)
```

Түсіндірме: базалық жағдай `n == 0`, қалғаны өз-өзін шақырады.

### 4) Рекурсивті тізім қосындысы

```python
def sum_items(items):
    if len(items) == 0:
        return 0
    return items[0] + sum_items(items[1:])
```

Түсіндірме: бос tuple болса тоқтайды, әйтпесе бірінші элементті қалғанымен қосады.

### 5) Compose жазу

```python
from functools import reduce

def compose(*functions):
    return lambda value: reduce(lambda acc, fn: fn(acc), reversed(functions), value)
```

Түсіндірме: функциялар оңнан солға орындалады.

### 6) Декоратор жазу

```python
from functools import wraps

def logged(function):
    @wraps(function)
    def wrapper(*args, **kwargs):
        print(function.__name__)
        return function(*args, **kwargs)
    return wrapper
```

Түсіндірме: wrapper бастапқы функцияны шақырмас бұрын атауын шығарады.

### 7) Sorted + lambda key

```python
items = ({"name": "a", "value": 3}, {"name": "b", "value": 1})
result = tuple(sorted(items, key=lambda item: item["value"]))
```

Түсіндірме: `key` әр элементтен салыстыру мәнін алады.

## 8. Әлсіз жерлер және қалай жауап беру

| Әлсіз жер | Неге сынауы мүмкін | Қалай жауап беру |
|---|---|---|
| PDF файл репода жоқ | «PDF acceptance толық тексерілді ме?» деп сұрауы мүмкін. | «PDF файл жобада жоқ болды, сондықтан тек README, тесттер және кодтағы талаптар бойынша тексердім. Егер PDF берілсе, айырмасын бөлек checklist қылып шығарамын». |
| `Rule.payload` mutable dict | Frozen dataclass ішіндегі dict-тің ішкі мәнін өзгертуге болады. | «Бұл икемділік үшін қалды, себебі rule payload әртүрлі. Толық immutable керек болса `MappingProxyType` немесе nested frozen model қолдануға болады». |
| `readings_stats(readings, sensors, kind)` сигнатурасы кеңейген | PDF тек `readings_stats(readings, kind)` деуі мүмкін. | «Reading ішінде kind жоқ, нормализация үшін kind Sensor-да сақталған. Сондықтан sensors параметрі қажет болды». |
| `load_seed` I/O жасайды | Таза функция емес деуі мүмкін. | «Иә, файл оқу side effect. Бірақ I/O шекарада ғана, ал негізгі core функциялар tuple алып, tuple қайтарады». |
| `sort_readings` белгісіз `by` үшін `KeyError` береді | Қате өңдеу жоқ. | «UI тек рұқсат етілген `ts/value/sensor` береді. Production үшін validation қосуға болады». |
| Async/FRP және Reports толық емес | Мәзірде бар, бірақ заглушка. | «Бұл жоба Лаб 1-2 және 1-4 дәрістерге арналған, кейінгі бөлімдер әдейі `page_later` ретінде қалдырылған». |
| `data/seed.json` үлкен | Қолмен қарау қиын. | «Ол генератордан жасалады, көлем талабы үшін 1440 reading керек болды; құрылымы Data бетінде expander арқылы көрінеді». |
| `main.py` session_state қолданады | UI state мутациясы бар. | «UI қабаты state ұстайды, бірақ функционалды ядро state-ті мутацияламайды. Яғни side effect шекара UI-де ғана». |

## 9. Қорғауға 10 сөйлемдік қысқа таныстырылым

1. Менің жобам климат және IoT датчиктерінің көрсеткіштерін көрсететін Streamlit дашборд.
2. Дерек `data/seed.json` файлынан жүктеледі және `Location`, `Device`, `Sensor`, `Reading`, `Rule`, `Alert` модельдеріне айналады.
3. Модельдер `frozen=True` dataclass ретінде жазылған, сондықтан объектілерді тікелей өзгертуге болмайды.
4. Негізгі есептеулер `app/core/transforms.py` ішінде таза функцияларға бөлінген.
5. `add_reading` және `apply_calibration` бастапқы tuple-ды өзгертпей, жаңа tuple қайтарады.
6. Статистика `filter`, `map`, `reduce` арқылы есептеледі.
7. Локация бойынша сүзу иерархияны рекурсиямен табады.
8. Pipeline бетінде closure, `all_of`, `pipe` және `partial` бірге қолданылады.
9. `compose.py` ішінде compose, pipe, curry және decorator мысалдары бар.
10. Жоба `pytest` арқылы тексерілді: 27 тест сәтті өтті.

## 10. 15 бақылау сұрағы жауабымен

1. **Immutable деген не?** Өзгермейтін дерек; мысал `@dataclass(frozen=True)`.
2. **Таза функция қандай?** Сыртқы күйді өзгертпей, кірістен шығыс қайтаратын функция.
3. **`add_reading` не қайтарады?** Жаңа Reading қосылған жаңа tuple.
4. **`apply_calibration` неге `replace` қолданады?** Frozen Sensor-ды өзгертпей, жаңа объект жасау үшін.
5. **`readings_stats` не есептейді?** Min, max, avg, count.
6. **Closure деген не?** Ішкі функция сыртқы мәнді есте сақтайды.
7. **`by_time_range` қандай closure сақтайды?** `start` және `end` мәндерін.
8. **Рекурсия қай жерде бар?** `collect_descendant_locations` және `nest_readings_by_day`.
9. **`pipe` не үшін керек?** Деректі функциялар тізбегінен солдан оңға өткізу үшін.
10. **`compose` қай бағытта орындайды?** Оңнан солға.
11. **`partial` не істейді?** Функция аргументтерінің бір бөлігін алдын ала бекітеді.
12. **Каррирование деген не?** Көп аргументті функцияны бір аргументті функциялар тізбегіне бөлу.
13. **Декоратор не істейді?** Функцияны орап, қосымша мінез қосады.
14. **`timed` не қайтарады?** `(result, elapsed_ms)` tuple-ын.
15. **Жоба қалай іске қосылады?** `.\.venv\Scripts\python.exe -m streamlit run app/main.py`.
